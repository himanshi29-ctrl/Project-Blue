# fight-depression-sadness
c++ program to test your level of happiness and provide you with a package of few days where you need to follow some steps to achieve highest peek of happiness and satisfaction.



Depression is a disease that affects millions of people around the world.Depression as an endemic problem only started from the 21st century.But this was not always the case.
The question is whats the causes of depression?the causes are complicated and not well understood. It is thought arises due to a combination of chemical imbalances in the brain, genetics and personal problems. But it can also be triggered through small innocent things we are exposed to on a daily basis.
In this fast paced world of instant communication where stories about people’s successes populate the news everyday, it can get a little overwhelming for us normal people. I feel insecure with my own life and ambitions. The news rarely runs stories about people’s failures, thereby skewing the perception of reality. People think that they are the only ones struggling with failure and mediocrity.
I want to provide support and advice to empower all Indians affected by symptoms of mental health.I want to promote understanding, reduce stigma and give a voice to those who have none. I aim to help individuals lift themselves out of the impacts of poor mental health, I seek to ensure that all people especially those with the fewest resources hold a good state of mental health to secure opportunities to succeed in life.


this c++ program is basically a prototype or the basis for the big project on depression.
this is how it presently looks like
![1](https://user-images.githubusercontent.com/54480699/66275448-4288fd80-e8a6-11e9-9555-7eb0063cbff2.PNG)
![2](https://user-images.githubusercontent.com/54480699/66275449-43219400-e8a6-11e9-90c2-9662b774afd2.PNG)

